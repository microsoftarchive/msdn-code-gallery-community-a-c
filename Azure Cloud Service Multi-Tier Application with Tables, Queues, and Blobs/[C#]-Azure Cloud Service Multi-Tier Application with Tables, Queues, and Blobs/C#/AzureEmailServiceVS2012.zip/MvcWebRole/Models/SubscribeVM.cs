﻿namespace MvcWebRole.Models
{
    public class SubscribeVM
    {
        public string EmailAddress { get; set; }
        public string ListDescription { get; set; }
    }
}