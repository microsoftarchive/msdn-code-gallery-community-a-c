/*
	Author: James Pate Williams, Jr. (c) 2002

	Windows sequencer
*/

#include <fcntl.h>
#include <io.h>
#include <string.h>
#include <time.h>
#include <windows.h>
#include <commdlg.h>
#include <winsock.h>
#include <mmsystem.h>
#include <process.h>
#include <stdlib.h>
#include <sys\stat.h>
#include "resource.h"

#define NUMBERBUTTONS 5
#define NOTEON 144
#define NOTEOFF 128
#define PROGRAM 192
#define bzero(s, n) memset((s), 0, (n))

typedef struct tagBuffer {
	BOOL white;
	DWORD note;
	int channel, currentKeyX0, currentKeyX1, currentKeyY0, currentKeyY1, index;
} Buffer;

typedef struct tagSocketData {
	int sequenceNumber;
	size_t length;
	time_t timestamp;
	DWORD midiData;
} SocketData;

char copyright[256], currentInstrument[16][32], instrument[128][32], title[256];
int bufferCount = 0, handle = - 1, k = - 1, sequenceNumber = 0, sockfd;
int fileCount, MIDIformat, whiteKeyHeight, whiteKeyWidth;
int currentInstrumentLength[16], textX[16], textY[16];
int blackKeyX0[30], blackKeyX1[30], blackKeyY0[30], blackKeyY1[30];
int whiteKeyX0[42], whiteKeyX1[42], whiteKeyY0[42], whiteKeyY1[42];
struct sockaddr_in cli_addr, serv_addr;
Buffer buffer[128];
BOOL connected = FALSE, paused = FALSE, started = FALSE;
CRITICAL_SECTION criticalSection;
DWORD channel = 0, inputPort = 0, outputPort = 0, program[16] = {0};
COLORREF color[16];
HBRUSH hBrush[16];
HPEN hPen[16];
HINSTANCE hInst;
HMIDIIN hMidiIn = NULL;
HMIDIOUT hMidiOut = NULL;
HWND hWnd;
HWND hwndButton[NUMBERBUTTONS];

/* data taken and modified from Sun source code MixerSequencer.java */

int   startTime            = 0;
int   startMillisecondTime = 0;
int   lastTempoChangeTime  = 0;
int   lastTempoChangeTick  = 0;
int   recordTempoInMPQ     = 500000; // 120 bpm in mpq
int   startTick            = 0;
float divisionType         = 0.0f;
int   resolution           = 0;

/* end of Sun variable definitions */

void PaintWindow(HDC hdc) {
	int j;

	for (j = 0; j < 42; j++)
		Rectangle(hdc, whiteKeyX0[j], whiteKeyY0[j], whiteKeyX1[j], whiteKeyY1[j]);
	for (j = 0; j < bufferCount; j++) {
		if (buffer[j].white) {
			RECT rect;

			rect.left = buffer[j].currentKeyX0;
			rect.top = buffer[j].currentKeyY0;
			rect.right = buffer[j].currentKeyX1;
			rect.bottom = buffer[j].currentKeyY1;
			FillRect(hdc, &rect, hBrush[buffer[j].channel]);
		}
	}
	for (j = 0; j < 30; j++) {
		RECT rect;

		rect.left = blackKeyX0[j];
		rect.top = blackKeyY0[j];
		rect.right = blackKeyX1[j];
		rect.bottom = blackKeyY1[j];
		FillRect(hdc, &rect, GetStockObject(BLACK_BRUSH));
	}
	for (j = 0; j < bufferCount; j++) {
		if (!buffer[j].white) {
			RECT rect;
	
			rect.left = buffer[j].currentKeyX0;
			rect.top = buffer[j].currentKeyY0;
			rect.right = buffer[j].currentKeyX1;
			rect.bottom = buffer[j].currentKeyY1;
			FillRect(hdc, &rect, hBrush[buffer[j].channel]);
		}
	}
}

void DrawKey(int channel, BOOL on, DWORD note) {
	int i, index, j, number, octave;
	int blackTrans[12] = {0, 0, 0, 1, 0, 0, 2, 0, 3, 0, 4, 0};
	int whiteTrans[12] = {0, 0, 1, 0, 2, 3, 0, 4, 0, 5, 0, 6};
	HDC hdc;
	RECT rect;

	EnterCriticalSection(&criticalSection);
	hdc = GetDC(hWnd);
	octave = (note - 24) / 12;
	number = (note - 24) % 12;
	if (number < 0)
		number += 12;
	if (on == TRUE) {
		buffer[bufferCount].note = note;
		if (number == 1 || number == 3 || number == 6 || number == 8 || number == 10) {
			index = 5 * octave + blackTrans[number];
			if (index < 30) {
				for (i = 0; i < bufferCount; i++)
					if (buffer[i].note == note)
						break;
				if (i == bufferCount) {
					buffer[bufferCount].white = FALSE;
					buffer[bufferCount].channel = channel;
					buffer[bufferCount].currentKeyX0 = blackKeyX0[index];
					buffer[bufferCount].currentKeyX1 = blackKeyX1[index];
					buffer[bufferCount].currentKeyY0 = blackKeyY0[index];
					buffer[bufferCount].currentKeyY1 = blackKeyY1[index];
					buffer[bufferCount].index = index;
					bufferCount++;
				}
				if (bufferCount > 128) {
					MessageBox(hWnd, "bufferCount < 128", "Error Message", MB_ICONSTOP | MB_OK);
					exit(1);
				}
				rect.left   = blackKeyX0[index];
				rect.top    = blackKeyY0[index];
				rect.right  = blackKeyX1[index];
				rect.bottom = blackKeyY1[index];
				FillRect(hdc, &rect, hBrush[buffer[bufferCount - 1].channel]);
			}
		}
		else {
			index = 7 * octave + whiteTrans[number];
			if (index < 42) {
				for (i = 0; i < bufferCount; i++)
					if (buffer[i].note == note)
						break;
				if (i == bufferCount) {
					buffer[bufferCount].white = TRUE;
					buffer[bufferCount].channel = channel;
					buffer[bufferCount].currentKeyX0 = whiteKeyX0[index];
					buffer[bufferCount].currentKeyX1 = whiteKeyX1[index];
					buffer[bufferCount].currentKeyY0 = whiteKeyY0[index];
					buffer[bufferCount].currentKeyY1 = whiteKeyY1[index];
					buffer[bufferCount].index = index;
					bufferCount++;
				}
				if (bufferCount > 128) {
					MessageBox(hWnd, "bufferCount < 128", "Error Message", MB_ICONSTOP | MB_OK);
					exit(1);
				}
				rect.left   = whiteKeyX0[index];
				rect.top    = whiteKeyY0[index];
				rect.right  = whiteKeyX1[index];
				rect.bottom = whiteKeyY1[index];				
				FillRect(hdc, &rect, hBrush[buffer[bufferCount - 1].channel]);
				if (number != 0 && number != 5) {
					index = 5 * octave + blackTrans[number - 1];
					if (index < 30) {
						rect.left   = blackKeyX0[index];
						rect.top    = blackKeyY0[index];
						rect.right  = blackKeyX1[index];
						rect.bottom = blackKeyY1[index];
						FillRect(hdc, &rect, GetStockObject(BLACK_BRUSH));
					}
				}
				if (number != 4 && number != 11) {
					index = 5 * octave + blackTrans[number + 1];
					if (index < 30) {
						rect.left   = blackKeyX0[index];
						rect.top    = blackKeyY0[index];
						rect.right  = blackKeyX1[index];
						rect.bottom = blackKeyY1[index];
						FillRect(hdc, &rect, GetStockObject(BLACK_BRUSH));
					}
				}
			}
		}
	}
	else {
		if (number == 1 || number == 3 || number == 6 || number == 8 || number == 10) {
			index = 5 * octave + blackTrans[number];
			if (index < 30) {
				for (i = 0; i < bufferCount; i++)
					if (buffer[i].note == note)
						break;
				if (i == bufferCount) {
					buffer[bufferCount].white = FALSE;
					buffer[bufferCount].channel = channel;
					buffer[bufferCount].currentKeyX0 = blackKeyX0[index];
					buffer[bufferCount].currentKeyX1 = blackKeyX1[index];
					buffer[bufferCount].currentKeyY0 = blackKeyY0[index];
					buffer[bufferCount].currentKeyY1 = blackKeyY1[index];
					buffer[bufferCount].index = index;
					bufferCount++;
				}
				if (bufferCount > 128) {
					MessageBox(hWnd, "bufferCount < 128", "Error Message", MB_ICONSTOP | MB_OK);
					exit(1);
				}
				rect.left   = blackKeyX0[index];
				rect.top    = blackKeyY0[index];
				rect.right  = blackKeyX1[index];
				rect.bottom = blackKeyY1[index];
				FillRect(hdc, &rect, GetStockObject(BLACK_BRUSH));
			}
		}
		else {
			index = 7 * octave + whiteTrans[number];
			if (index < 42) {
				rect.left   = whiteKeyX0[index];
				rect.top    = whiteKeyY0[index];
				rect.right  = whiteKeyX1[index];
				rect.bottom = whiteKeyY1[index];				
				Rectangle(hdc, rect.left, rect.top, rect.right, rect.bottom);
				rect.left   = whiteKeyX0[index] + 1;
				rect.top    = whiteKeyY0[index] + 1;
				rect.right  = whiteKeyX1[index] - 1;
				rect.bottom = whiteKeyY1[index] - 1;	
				FillRect(hdc, &rect, GetStockObject(WHITE_BRUSH));
				if (number != 0 && number != 5) {
					index = 5 * octave + blackTrans[number - 1];
					if (index < 30) {
						rect.left   = blackKeyX0[index];
						rect.top    = blackKeyY0[index];
						rect.right  = blackKeyX1[index];
						rect.bottom = blackKeyY1[index];
						FillRect(hdc, &rect, GetStockObject(BLACK_BRUSH));
					}
				}
				if (number != 4 && number != 11) {
					index = 5 * octave + blackTrans[number + 1];
					if (index < 30) {
						rect.left   = blackKeyX0[index];
						rect.top    = blackKeyY0[index];
						rect.right  = blackKeyX1[index];
						rect.bottom = blackKeyY1[index];
						FillRect(hdc, &rect, GetStockObject(BLACK_BRUSH));
					}
				}
			}
		}
		for (i = 0; i < bufferCount; i++)
			if (buffer[i].note == note)
				break;
		if (i < bufferCount) {
			for (j = i; j < bufferCount - 1; j++)
				buffer[j] = buffer[j + 1];
			bufferCount--;
			if (bufferCount < 0) {
				MessageBox(hWnd, "bufferCount < 0", "Error Message", MB_ICONSTOP | MB_OK);
				exit(1);
			}
		}
	}
	ReleaseDC(hWnd, hdc);
	LeaveCriticalSection(&criticalSection);
}

void CALLBACK MidiInProc(HMIDIIN hMidiIn, UINT wMsg, DWORD dwInstance, 
						 DWORD dwParam1, DWORD dwParam2) {
	static int i = 0;
	static SocketData socketData[16];
	DWORD d1 = (dwParam1 & 0xFF);
	DWORD d2 = (d1 & 0xF0);
	DWORD d3 = (d1 & 0x0F);
	DWORD dNote = (dwParam1 & 0xFF00) >> 8;
	DWORD dVelo = (dwParam1 & 0x00FF0000) >> 16;
	HDC hdc;

	if (dwParam1 != 0 && d1 != 0xFE) {
		DWORD dWord = (dVelo << 16) + (dNote << 8) + d1;
		if (dWord != 0) {
			midiOutShortMsg(hMidiOut, dWord);
			if (d2 == NOTEON && dVelo != 0)
				DrawKey((int) d3, TRUE, dNote);
			else if ((d2 == NOTEON && dVelo == 0) || d2 == NOTEOFF)
				DrawKey((int) d3, FALSE, dNote);
			else if (d2 == PROGRAM) {
				int j, len;

				EnterCriticalSection(&criticalSection);
				program[d3] = dNote;
				
				len = wsprintf(currentInstrument[d3], "%02d %s", d3, instrument[dNote]);
				for (j = len; j < 31; j++)
					currentInstrument[d3][j] = ' ';
				hdc = GetDC(hWnd);
				TextOut(hdc, textX[d3], textY[d3], currentInstrument[d3],
					currentInstrumentLength[d3]);
				ReleaseDC(hWnd, hdc);
				LeaveCriticalSection(&criticalSection);
			}
			if (connected == TRUE) {
				int j;

				socketData[i].sequenceNumber = htonl(sequenceNumber++);
				socketData[i].length = htonl(sizeof(socketData[i]));
				socketData[i].timestamp = htonl(clock());
				socketData[i].midiData = htonl(dWord);
				i++;
				if (i == k) {
					if (sendto(sockfd, (char *) socketData, k * sizeof(SocketData), 0, 
						(struct sockaddr *) &serv_addr, sizeof(serv_addr)) !=
						k * (int) sizeof(SocketData)) {
						MessageBox(hWnd, "can't sendto server socket data", "Error Message",
							MB_ICONSTOP | MB_OK);
						exit(1);
					}
					i = k - 1;
					for (j = 0; j < i; j++)
						socketData[j] = socketData[j + 1];
				}
			}
		}
	}
	if (connected == FALSE)
		i = 0;
}

int calculateElapsedTime(int tick) {
	if (divisionType == 0.0f)
		return tick * recordTempoInMPQ / (resolution * 1000);
	else
		return (int) (1000 * tick / (divisionType * resolution));
}

typedef struct tagEvent {
	BOOL smFlag;
	char metaMessage;
	DWORD shortMessage;
	int tick;
} Event;

int eventCount = 0;
Event *event = NULL;

void siftUp(int i, int n, Event *array) {
	Event copy = array[i];
		
	while (TRUE) {
		int j = 2 * i;
		
		if (j <= n) {
			Event mj;

			if (j < n) {
				Event m1 = array[j + 1];
				Event m2 = array[j];
			
				if (m1.tick > m2.tick) 
					j++;
			}
			mj = array[j];
			if (mj.tick > copy.tick) {
				array[i] = array[j];
				i = j;
			}
			else
				break;
		}
		else
			break;
	}
	array[i] = copy;
}

void TreeSort3(int count, Event *array) {
	int i;
	Event temp;

	for (i = count / 2; i >= 1; i--)
		siftUp(i, count - 1, array);
	for (i = count - 1; i >= 1; i--) {
		siftUp(0, i, array);
		temp = array[0];
		array[0] = array[i];
		array[i] = temp;
	}
}

int readFormatOne(char *last, char *ptr, int tracks) {
	int currentTick, i, k, length, w[4];
	int number = (int) (last - ptr + 1);
	BOOL p, s;
	
	eventCount = 0;
	event = malloc(number * sizeof(Event));
	if (event == NULL)
		return - 1;
	for (k = 0; k < tracks; k++) {
		/* check for MTrk header */
		if (*ptr == 'M' && *(ptr + 1) == 'T' && *(ptr + 2) == 'r' && *(ptr + 3) == 'k') {
			ptr += 4;
			if (ptr >= last)
				return 7;
			for (i = 0; i < 4; i++) {
				w[i] = *ptr++;
				if (w[i] < 0)
					w[i] += 256;
			}
			length = (w[0] << 24) + (w[1] << 16) + (w[2] << 8) + w[3];
			currentTick = 0;
			while (ptr < last) {
				char ch;
				int d, t;

				ch = *ptr++;
				if (ptr >= last)
					return 8;
				if (ch & 0x80) {
					t = ch & 0x7F;
					do {
						ch = *ptr++;
						if (ptr >= last)
							return 9;
						t = (t << 7) + (ch & 0x7F);
					} while (ch & 0x80);
				}
				else
					t = ch;
				currentTick += t;
				if (*ptr == - 1) {
					ptr++;
					if (ptr >= last)
						return 10;
					event[eventCount].smFlag = FALSE;
					event[eventCount].metaMessage = *ptr;
					event[eventCount].tick = currentTick;
					if ((*ptr >= 1 && *ptr <= 7)) {
						BOOL one = FALSE, two = FALSE;

						if (*ptr == 1)
							one = TRUE;
						if (*ptr == 2)
							two = TRUE;
						ptr++;
						if (ptr >= last)
							return 11;
						ch = *ptr++;
						if (ptr >= last)
							return 12;
						if (ch & 0x80) {
							d = ch & 0x7F;
							do {
								ch = *ptr++;
								if (ptr >= last)
									return 13;
								d = (d << 7) + (ch & 0x7F);
							} while (ch & 0x80);
						}
						else
							d = ch;
						if (one) {
							if (d < 256) {
								strcpy(title, ptr);
								title[d] = '\0';
							}
							else
								title[0] = '\0';
						}
						if (two) {
							if (d < 256) {
								strcpy(copyright, ptr);
								copyright[d] = '\0';
							}
							else
								copyright[0] = '\0';
						}
						ptr += d;
						if (ptr >= last)
							return 14;
					}
					else if (*ptr == 47) {
						ptr++;
						if (ptr == last && k == tracks - 1)
							break;
						while (*ptr != 'M' && ptr < last)
							ptr++;
						if (ptr >= last && k != tracks - 1)
							return 33;
						break;
					}
					else if (*ptr == 81) {
						ptr += 2;
						if (ptr >= last)
							return 15;
						for (i = 0; i < 3; i++) {
							w[i] = *ptr++;
							if (ptr >= last)
								return 16;
							if (w[i] < 0)
								w[i] += 256;
						}
						d = (w[0] << 16) + (w[1] << 8) + w[2];
						event[eventCount].shortMessage = d;
					}
					else if (*ptr == 88) {
						ptr += 2;
						event[eventCount].shortMessage = (*ptr << 24) + (*(ptr + 1) << 16) + (*(ptr + 2) << 8) + *(ptr + 3);
						ptr += 4;
						if (ptr >= last)
							return 17;
					}
					else if (*ptr == 89) {
						ptr += 4;
						if (ptr >= last)
							return 18;
					}
					eventCount++;
				}
				else {
					DWORD cc = 0, command = 0, nn = 0, pp = 0, vv = 0;
					static DWORD lastCommand = 0;

					if (*ptr < 0) {
						ch = *ptr++;
						if (ptr >= last)
							return 19;
						if (ch & 0x80)
							command = ch + 256;
					}
					else
						command = lastCommand;
					if ((command >= 128 && command <= 143) || (command >= 144 && command <= 159)) {
						ch = *ptr++;
						if (ptr >= last)
							return 20;
						nn = ch;
						ch = *ptr++;
						if (ptr >= last)
							return 21;
						vv = ch;
						d = command + (nn << 8) + (vv << 16);
					}
					else if (command >= 176 && command <= 191) {
						ch = *ptr++;
						if (ptr >= last)
							return 22;
						cc = ch;
						ch = *ptr++;
						if (ptr >= last)
							return 23;
						vv = ch;
						d = command + (cc << 8) + (vv << 16);
					}
					else if (command >= 192 && command <= 207) {
						ch = *ptr++;
						if (ptr >= last)
							return 24;
						pp = ch;
						d = command + (pp << 8);
					}
					else if (command >= 208 && command <= 223) {
						ch = *ptr++;
						if (ptr >= last)
							return 25;
						vv = ch;
						d = command + (vv << 8);
					}
					else if (command >= 224 && command <= 239) {
						ch = *ptr++;
						if (ptr >= last)
							return 26;
						nn = ch;
						ch = *ptr++;
						if (ptr >= last)
							return 27;
						vv = ch;
						d = command + (nn << 8) + (vv << 16);
					}
					lastCommand = command;
					event[eventCount].smFlag = TRUE;
					event[eventCount].metaMessage = '\0';
					event[eventCount].tick = currentTick;
					event[eventCount++].shortMessage = d;
				}
			}
		}
		else 
			return 30;
	}
	TreeSort3(eventCount, event);
	currentTick = 0;
	for (i = 0; i < eventCount; i++) {
		while (TRUE) {
			EnterCriticalSection(&criticalSection);
			p = paused;
			s = started;
			LeaveCriticalSection(&criticalSection);
			if (!paused)
				break;
		}
		if (!s)
			return 0;
		Sleep(calculateElapsedTime(event[i].tick - currentTick));
		currentTick = event[i].tick;
		if (event[i].smFlag)
			MidiInProc(hMidiIn, MIM_DATA, (DWORD) hInst, (DWORD) event[i].shortMessage, (DWORD) 0);
		else
			if (event[i].metaMessage == 81)
				recordTempoInMPQ = event[i].shortMessage;
	}
	return 0;
}

int readFile(void) {
	char *fileBuffer, *last, *ptr;
	int bytes, division, format, i, length, tracks, w[4];
	long fLength = filelength(handle);
	BOOL p, s;
	DWORD lastCommand = 0;

	fileBuffer = (char *) malloc(fLength);
	if (fileBuffer == NULL)
		return - 1;
	bytes = read(handle, fileBuffer, fLength);
	if (bytes == - 1) {
		free(fileBuffer);
		return 1;
	}
	close(handle);

	/* check for MThd chunk at beginning of the file */
	ptr = fileBuffer;
	last = ptr + fLength;
	if (*ptr == 'M' && *(ptr + 1) == 'T' && *(ptr + 2) == 'h' && *(ptr + 3) == 'd') {
		ptr += 4;
		if (ptr >= last) {
			free(fileBuffer);
			return 2;
		}
		for (i = 0; i < 4; i++) {
			w[i] = *ptr++;
			if (ptr >= last) {
				free(fileBuffer);
				return 3;
			}
			if (w[i] < 0)
				w[i] += 256;
		}
		length = (w[0] << 24) + (w[1] << 16) + (w[2] << 8) + w[3];
		if (length == 6) {
			for (i = 0; i < 2; i++) {
				w[i] = *ptr++;
				if (ptr >= last) {
					free(fileBuffer);
					return 4;
				}
				if (w[i] < 0)
					w[i] += 256;
			}
			format = (w[0] << 8) + w[1];
			MIDIformat = format;
			/* we currently only support format 0 and format 1 file */
			if (format == 0 || format == 1) {
				for (i = 0; i < 2; i++) {
					w[i] = *ptr++;
					if (ptr >= last) {
						free(fileBuffer);
						return 5;
					}
					if (w[i] < 0)
						w[i] += 256;
				}
				tracks = (w[0] << 8) + w[1];
				for (i = 0; i < 2; i++) {
					w[i] = *ptr++;
					if (ptr >= last) {
						free(fileBuffer);
						return 6;
					}
					if (w[i] < 0)
						w[i] += 256;
				}
				resolution = division = (w[0] << 8) + w[1];
				if (format == 1) {
					int code = readFormatOne(last, ptr, tracks);

					free(fileBuffer);
					return code;
				}
				/* check for MTrk header */
				if (*ptr == 'M' && *(ptr + 1) == 'T' && *(ptr + 2) == 'r' && *(ptr + 3) == 'k') {
					ptr += 4;
					if (ptr >= last) {
						free(fileBuffer);
						return 7;
					}
					for (i = 0; i < 4; i++) {
						w[i] = *ptr++;
						if (w[i] < 0)
							w[i] += 256;
					}
					length = (w[0] << 24) + (w[1] << 16) + (w[2] << 8) + w[3];
					if (fLength - 22 == length) {
						eventCount = 0;
						event = malloc(length * sizeof(Event));
						while (ptr < last) {
							char ch;
							int d, t;

							ch = *ptr++;
							if (ptr >= last) {
								free(fileBuffer);
								return 8;
							}
							while (TRUE) {
								EnterCriticalSection(&criticalSection);
								p = paused;
								s = started;
								LeaveCriticalSection(&criticalSection);
								if (!paused)
									break;
							}
							if (!s) {
								free(fileBuffer);
								return 0;
							}
							if (ch & 0x80) {
								t = ch & 0x7F;
								do {
									ch = *ptr++;
									if (ptr >= last) {
										free(fileBuffer);
										return 9;
									}
									t = (t << 7) + (ch & 0x7F);
								} while (ch & 0x80);
							}
							else
								t = ch;
							Sleep(calculateElapsedTime(t));
							if (*ptr == - 1) {
								ptr++;
								if (ptr >= last) {
									free(fileBuffer);
									return 10;
								}
								if ((*ptr >= 1 && *ptr <= 7)) {
									BOOL one = FALSE, two = FALSE;

									if (*ptr == 1)
										one = TRUE;
									if (*ptr == 2)
										two = TRUE;
									ptr++;
									if (ptr >= last) {
										free(fileBuffer);
										return 11;
									}
									ch = *ptr++;
									if (ptr >= last) {
										free(fileBuffer);
										return 12;
									}
									if (ch & 0x80) {
										d = ch & 0x7F;
										do {
											ch = *ptr++;
											if (ptr >= last) {
												free(fileBuffer);
												return 13;
											}
											d = (d << 7) + (ch & 0x7F);
										} while (ch & 0x80);
									}
									else
										d = ch;
									if (one) {
										if (d < 256) {
											strcpy(title, ptr);
											title[d] = '\0';
										}
										else
											title[0] = '\0';
									}
									if (two) {
										if (d < 256) {
											strcpy(copyright, ptr);
											copyright[d] = '\0';
										}
										else
											copyright[0] = '\0';
									}
									ptr += d;
									if (ptr >= last) {
										free(fileBuffer);
										return 14;
									}
								}
								else if (*ptr == 47) {
									free(fileBuffer);
									return 0;
								}
								else if (*ptr == 81) {
									ptr += 2;
									if (ptr >= last) {
										free(fileBuffer);
										return 15;
									}
									for (i = 0; i < 3; i++) {
										w[i] = *ptr++;
										if (ptr >= last) {
											free(fileBuffer);
											return 16;
										}
										if (w[i] < 0)
											w[i] += 256;
									}
									d = (w[0] << 16) + (w[1] << 8) + w[2];
									recordTempoInMPQ = d;
									event[eventCount].metaMessage = 81;
									event[eventCount].smFlag = FALSE;
									event[eventCount].shortMessage = d;
									event[eventCount++].tick = t;
								}
								else if (*ptr == 88) {
									ptr += 2;
									event[eventCount].metaMessage = 88;
									event[eventCount].smFlag = FALSE;
									event[eventCount].shortMessage = (*ptr << 24) + (*(ptr + 1) << 16) + (*(ptr + 2) << 8)
										+ *(ptr + 3);
									event[eventCount++].tick = t;
									ptr += 4;
									if (ptr >= last) {
										free(fileBuffer);
										return 17;
									}
								}
								else if (*ptr == 89) {
									ptr += 4;
									if (ptr >= last) {
										free(fileBuffer);
										return 18;
									}
								}
							}
							else {
								DWORD cc = 0, command = 0, nn = 0, pp = 0, vv = 0;

								if (*ptr < 0) {
									ch = *ptr++;
									if (ptr >= last) {
										free(fileBuffer);
										return 19;
									}
									if (ch & 0x80)
										command = ch + 256;
								}
								else
									command = lastCommand;
								if ((command >= 128 && command <= 143) || (command >= 144 && command <= 159)) {
									ch = *ptr++;
									if (ptr >= last) {
										free(fileBuffer);
										return 20;
									}
									nn = ch;
									ch = *ptr++;
									if (ptr >= last) {
										free(fileBuffer);
										return 21;
									}
									vv = ch;
									d = command + (nn << 8) + (vv << 16);
								}
								else if (command >= 176 && command <= 191) {
									ch = *ptr++;
									if (ptr >= last) {
										free(fileBuffer);
										return 22;
									}
									cc = ch;
									ch = *ptr++;
									if (ptr >= last) {
										free(fileBuffer);
										return 23;
									}
									vv = ch;
									d = command + (cc << 8) + (vv << 16);
								}
								else if (command >= 192 && command <= 207) {
									ch = *ptr++;
									if (ptr >= last) {
										free(fileBuffer);
										return 24;
									}
									pp = ch;
									d = command + (pp << 8);
								}
								else if (command >= 208 && command <= 223) {
									ch = *ptr++;
									if (ptr >= last) {
										free(fileBuffer);
										return 25;
									}
									vv = ch;
									d = command + (vv << 8);
								}
								else if (command >= 224 && command <= 239) {
									ch = *ptr++;
									if (ptr >= last) {
										free(fileBuffer);
										return 26;
									}
									nn = ch;
									ch = *ptr++;
									if (ptr >= last) {
										free(fileBuffer);
										return 27;
									}
									vv = ch;
									d = command + (nn << 8) + (vv << 16);
								}
								event[eventCount].smFlag = TRUE;
								event[eventCount].shortMessage = d;
								event[eventCount++].tick = t;
								lastCommand = command;
								MidiInProc(hMidiIn, MIM_DATA, (DWORD) hInst, (DWORD) d, (DWORD) 0);
							}
						}
					}
					else {
						free(fileBuffer);
						return 28;
					}
				}
				else {
					free(fileBuffer);
					return 29;
				}
			}
			else {
				free(fileBuffer);
				return 30;
			}
		}
		else {
			free(fileBuffer);
			return 31;
		}
	}
	else {
		free(fileBuffer);
		return 32;
	}
	free(fileBuffer);
	return 0;
}

void Thread(PVOID pvoid) {
	clock_t clock0 = clock(), clock1;
	char message[128], format[128];
	double totalSeconds;
	int error = readFile(), minutes, seconds;

	clock1 = clock() - clock0;
	totalSeconds = (double) clock1 / CLOCKS_PER_SEC;
	minutes = (int) (totalSeconds / 60.0);
	seconds = (int) (totalSeconds - 60.0 * minutes);
	if (error == - 1)
		strcpy(format, "out of memory error\n");
	else if (error == 0)
		strcpy(format, "execution ok\n");
	else if (error == 1)
		strcpy(format, "could not read file error\n");
	else if (error >= 2 && error <= 6)
		strcpy(format, "corrupt MThd chunk in MIDI file error\n");
	else if (error == 7)
		strcpy(format, "corrupt MTrk chunk in MIDI file error\n");
	else if (error == 30)
		strcpy(format, "MIDI file is not of type 0\n");
	else
		strcpy(format, "corrupt MIDI file error\n");
	strcat(format, "error code = %d\n");
	if (seconds < 10)
		strcat(format, "time %d:0%d\n");
	else
		strcat(format, "time %d:%d\n");
	EnterCriticalSection(&criticalSection);
	bufferCount = 0;
	paused = FALSE;
	started = FALSE;
	SetWindowText(hwndButton[1], "Open");
	ShowWindow(hwndButton[3], FALSE);
	LeaveCriticalSection(&criticalSection);
	wsprintf(message, format, error, minutes, seconds);
	MessageBox(hWnd, message, "Information Message", MB_OK);
	ShowWindow(hwndButton[4], TRUE);
}

void Connect(char *host, int port) {
	int n, byte[32];
	struct hostent *she;
	ULONG sIPAddress;

	connected = FALSE;
	bzero((char *) &serv_addr, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	if ((she = gethostbyname(host)) != 0) {
		for (n = 0; n < she->h_length; n++) {
			byte[n] = (int) she->h_addr_list[0][n];
			if (byte[n] < 0)
				byte[n] += 256;
		}
		sIPAddress = (byte[0] << 24) + (byte[1] << 16) + (byte[2] << 8) + byte[3];
		serv_addr.sin_addr.s_addr = htonl(sIPAddress);
	}
	else
		serv_addr.sin_addr.s_addr = inet_addr(host);
	serv_addr.sin_port = htons((short) port);
	if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		MessageBox(hWnd, "can't open datagram socket", "Warning Message",
			MB_ICONEXCLAMATION | MB_OK);
		return;
	}
	bzero((char *) &cli_addr, sizeof(cli_addr));
	cli_addr.sin_family = AF_INET;
	cli_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	cli_addr.sin_port = htons(0);
	if (bind(sockfd, (struct sockaddr *) &cli_addr, sizeof(cli_addr)) < 0) {
		MessageBox(hWnd, "can't bind local address", "Warning Message",
			MB_ICONEXCLAMATION | MB_OK);
		return;
	}
	sequenceNumber = 0;
	connected = TRUE;
}

void InitInstrument(void) {
	strcpy(instrument[0], "Piano");
	strcpy(instrument[1], "Bright Piano");
	strcpy(instrument[2], "Electric Grand");
	strcpy(instrument[3], "Honky Tonk Piano");
	strcpy(instrument[4], "Electric Piano 1");
	strcpy(instrument[5], "Electric Piano 2");
	strcpy(instrument[6], "Harpsichord");
	strcpy(instrument[7], "Clavinet");
	strcpy(instrument[8], "Celesta");
	strcpy(instrument[9], "Glockenspiel");
	strcpy(instrument[10], "Music Box");
	strcpy(instrument[11], "Vibraphone");
	strcpy(instrument[12], "Marimba");
	strcpy(instrument[13], "Xylophone");
	strcpy(instrument[14], "Tubular Bell");
	strcpy(instrument[15], "Dulcimer");
	strcpy(instrument[16], "Hammond Organ");
	strcpy(instrument[17], "Perc Organ");
	strcpy(instrument[18], "Rock Organ");
	strcpy(instrument[19], "Church Organ");
	strcpy(instrument[20], "Reed Organ");
	strcpy(instrument[21], "Accordion");
	strcpy(instrument[22], "Harmonica");
	strcpy(instrument[23], "Tango Accordion");
	strcpy(instrument[24], "Nylon Str Guitar");
	strcpy(instrument[25], "Steel String Guitar");
	strcpy(instrument[26], "Jazz Electric Gtr");
	strcpy(instrument[27], "Clean Guitar");
	strcpy(instrument[28], "Muted Guitar");
	strcpy(instrument[29], "Overdrive Guitar");
	strcpy(instrument[30], "Distortion Guitar");
	strcpy(instrument[31], "Guitar Harmonics");
	strcpy(instrument[32], "Acoustic Bass");
	strcpy(instrument[33], "Fingered Bass");
	strcpy(instrument[34], "Picked Bass");
	strcpy(instrument[35], "Fretless Bass");
	strcpy(instrument[36], "Slap Bass 1");
	strcpy(instrument[37], "Slap Bass 2");
	strcpy(instrument[38], "Syn Bass 1");
	strcpy(instrument[39], "Syn Bass 2");
	strcpy(instrument[40], "Violin");
	strcpy(instrument[41], "Viola");
	strcpy(instrument[42], "Cello");
	strcpy(instrument[43], "Contrabass");
	strcpy(instrument[44], "Tremolo Strings");
	strcpy(instrument[45], "Pizzicato Strings");
	strcpy(instrument[46], "Orchestral Harp");
	strcpy(instrument[47], "Timpani");
	strcpy(instrument[48], "Ensemble Strings");
	strcpy(instrument[49], "Slow Strings");
	strcpy(instrument[50], "Synth Strings 1");
	strcpy(instrument[51], "Synth Strings 2");
	strcpy(instrument[52], "Choir Aahs");
	strcpy(instrument[53], "Voice Oohs");
	strcpy(instrument[54], "Syn Choir");
	strcpy(instrument[55], "Orchestra Hit");
	strcpy(instrument[56], "Trumpet");
	strcpy(instrument[57], "Trombone");
	strcpy(instrument[58], "Tuba");
	strcpy(instrument[59], "Muted Trumpet");
	strcpy(instrument[60], "French Horn");
	strcpy(instrument[61], "Brass Ensemble");
	strcpy(instrument[62], "Syn Brass 1");
	strcpy(instrument[63], "Syn Brass 2");
	strcpy(instrument[64], "Soprano Sax");
	strcpy(instrument[65], "Alto Sax");
	strcpy(instrument[66], "Tenor Sax");
	strcpy(instrument[67], "Baritone Sax");
	strcpy(instrument[68], "Oboe");
	strcpy(instrument[69], "English Horn");
	strcpy(instrument[70], "Bassoon");
	strcpy(instrument[71], "Clarinet");
	strcpy(instrument[72], "Piccolo");
	strcpy(instrument[73], "Flute");	
	strcpy(instrument[74], "Recorder");
	strcpy(instrument[75], "Pan Flute");
	strcpy(instrument[76], "Bottle Blow");
	strcpy(instrument[77], "Shakuhachi");
	strcpy(instrument[78], "Whistle");
	strcpy(instrument[79], "Ocarina");
	strcpy(instrument[80], "Syn Square Wave");
	strcpy(instrument[81], "Syn Saw Wave");
	strcpy(instrument[82], "Syn Calliope");
	strcpy(instrument[83], "Syn Chiff");
	strcpy(instrument[84], "Syn Charang");
	strcpy(instrument[85], "Syn Voice");
	strcpy(instrument[86], "Syn Fifths Saw");
	strcpy(instrument[87], "Syn Brass and Lead");
	strcpy(instrument[88], "Fantasia");
	strcpy(instrument[89], "Warm Pad");
	strcpy(instrument[90], "Polysynth");
	strcpy(instrument[91], "Space Vox");
	strcpy(instrument[92], "Bowed Glass");
	strcpy(instrument[93], "Metal Pad");
	strcpy(instrument[94], "Halo Pad");
	strcpy(instrument[95], "Sweep Pad");
	strcpy(instrument[96], "Ice Rain");
	strcpy(instrument[97], "Soundtrack");
	strcpy(instrument[98], "Crystal");
	strcpy(instrument[99], "Atmosphere");
	strcpy(instrument[100], "Brightness");
	strcpy(instrument[101], "Goblins");
	strcpy(instrument[102], "Echo Drops");
	strcpy(instrument[103], "Sci Fi");
	strcpy(instrument[104], "Sitar");
	strcpy(instrument[105], "Banjo");
	strcpy(instrument[106], "Shamisen");
	strcpy(instrument[107], "Koto");
	strcpy(instrument[108], "Kalimba");
	strcpy(instrument[109], "Bag Pipe");
	strcpy(instrument[110], "Fiddle");
	strcpy(instrument[111], "Shanai");
	strcpy(instrument[112], "Tinkle Bell");
	strcpy(instrument[113], "Agogo");
	strcpy(instrument[114], "Steel Drums");
	strcpy(instrument[115], "Woodblock");
	strcpy(instrument[116], "Taiko Drum");
	strcpy(instrument[117], "Melodic Tom");
	strcpy(instrument[118], "Syn Drum");
	strcpy(instrument[119], "Reverse Cymbal");
	strcpy(instrument[120], "Guitar Fret Noise");
	strcpy(instrument[121], "Breath Noise");
	strcpy(instrument[122], "Seashore");
	strcpy(instrument[123], "Bird");
	strcpy(instrument[124], "Telephone");
	strcpy(instrument[125], "Helicopter");
	strcpy(instrument[126], "Applause");
	strcpy(instrument[127], "Gunshot");
}

BOOL CALLBACK HostPortDlgProc(HWND hDlg, UINT iMsg, WPARAM wParam, LPARAM lParam) {
	char host[256], port[256], kString[256];
	int p;
	HWND hwndHost, hwndK, hwndPort;

	switch (iMsg) {
		case WM_INITDIALOG:
			return TRUE;
		case WM_COMMAND:
			switch (LOWORD(wParam)) {
				case IDOK:
					EndDialog(hDlg, 0);
					hwndHost = GetDlgItem(hDlg, IDC_EDIT1);
					GetWindowText(hwndHost, host, 256);
					hwndPort = GetDlgItem(hDlg, IDC_EDIT2);
					GetWindowText(hwndPort, port, 256);
					hwndK = GetDlgItem(hDlg, IDC_EDIT3);
					GetWindowText(hwndK, kString, 256);
					k = atoi(kString);
					p = atoi(port);
					if (p < 0 || p > 65535) {
						MessageBox(hWnd, "Port must be between 0 and 65535", "Warning Message",
							MB_ICONEXCLAMATION | MB_OK);
						return TRUE;
					}
					if (k < 1 || k > 16) {
						MessageBox(hWnd, "k < 1 or k > 16", "Warning Message",
							MB_ICONEXCLAMATION | MB_OK);
						return TRUE;
					}
					if (strlen(host) == 0) {
						MessageBox(hWnd, "zero length host name or address", "Warning Message",
							MB_ICONEXCLAMATION | MB_OK);
						return TRUE;
					}
					Connect(host, p);
					return TRUE;
				case IDCANCEL:
					EndDialog(hDlg, 0);
					return TRUE;
			}
	}
	return FALSE;
}

BOOL CALLBACK OutputDlgProc(HWND hDlg, UINT iMsg, WPARAM wParam, LPARAM lParam) {
	HWND comboBox = GetDlgItem(hDlg, IDC_COMBO1);
	static MIDIOUTCAPS *midiOutCaps;
	UINT i, nDevices;

	switch (iMsg) {
		case WM_INITDIALOG:
			nDevices = midiOutGetNumDevs();
			midiOutCaps = malloc(nDevices * sizeof(MIDIOUTCAPS));
			if (midiOutCaps == NULL) {
				MessageBox (hWnd, "can't allocate input device capabilities array", 
							"Error Message", MB_ICONSTOP | MB_OK);
				exit(1);
			}
			for (i = 0; i < nDevices; i++) {
				if (midiOutGetDevCaps(i, &midiOutCaps[i], sizeof(MIDIOUTCAPS)) !=
					MMSYSERR_NOERROR) {
					MessageBox (hWnd, "can't get output device capabilities", 
								"Error Message", MB_ICONSTOP | MB_OK);
					exit(1);
				}
				SendMessage(comboBox, CB_ADDSTRING, 0, (LPARAM) midiOutCaps[i].szPname);
			}
			SendMessage(comboBox, CB_SELECTSTRING, 0, (LPARAM) midiOutCaps[outputPort].szPname);
			return TRUE;
		case WM_COMMAND:
			switch (LOWORD(wParam)) {
				case IDOK:
					EndDialog(hDlg, 0);
					if (hMidiOut != NULL)
						midiOutClose(hMidiOut);
					if (midiOutOpen(&hMidiOut, outputPort, CALLBACK_NULL, CALLBACK_NULL, CALLBACK_NULL) != 
						MMSYSERR_NOERROR) {
						MessageBox (hWnd, "can't get open synthesizer", "Error Message",
								MB_ICONSTOP | MB_OK);
						exit(1);
					}
					return TRUE;
				case IDCANCEL:
					EndDialog(hDlg, 0);
					return TRUE;
				case IDC_COMBO1:
					if (HIWORD(wParam) == CBN_SELCHANGE) {
						outputPort = SendMessage(comboBox, CB_GETCURSEL, 0, 0L);
						SendMessage(comboBox, CB_SELECTSTRING, 0,
							(LPARAM) midiOutCaps[outputPort].szPname);
					}
					return TRUE;
			}
	}
	return FALSE;
}

#define MoveTo(hdc, x, y) MoveToEx(hdc, x, y, NULL)

typedef struct tagNote {
	double duration;
	DWORD channel, note;
} Note;

int rTempoInMPQ;
int *pagePtr = NULL;

void DrawNotes(HWND hDlg, BOOL forward, int *page) {
	char message[128];
	int deltaX, deltaY, drawHeight, drawWidth, xOrigin, yOrigin;
	int height, i, j, noteCount, width, x, y;
	Note noteArray[22];
	HDC hdc = GetDC(hDlg);
	COLORREF gray = GetSysColor(CTLCOLOR_DLG);
	HPEN blackPen = GetStockObject(BLACK_PEN), dottedPen;
	RECT clearRect, rect;
	static DWORD denom = 0, numer = 0;

	if (page == 0)
		denom = numer = 0;
	if (!forward) {
		(*page)--;
		if (*page < 0) {
			denom = numer = 0;
			*page = 0;
		}
	}
	if (strlen(title) > 50)
		title[50] = '\0';
	if (strlen(copyright) > 50)
		copyright[50] = '\0';
	SetBkColor(hdc, gray);
	TextOut(hdc, 32, 32, title, strlen(title));
	TextOut(hdc, 32, 64, copyright, strlen(copyright));
	wsprintf(message, "Page: %05d", *page + 1);
	TextOut(hdc, 32, 96, message, strlen(message));
	GetWindowRect(hDlg, &rect);
	SelectObject(hdc, blackPen);
	height = rect.bottom - rect.top;
	GetWindowRect(hDlg, &rect);
	width = rect.right - rect.left;
	drawHeight = height - 2 * height / 5;
	drawWidth = width - 2 * width / 5;
	deltaX = drawWidth / 26;
	deltaY = drawHeight / 26;
	xOrigin = width / 5;
	yOrigin = height / 5;
	clearRect.left = xOrigin;
	clearRect.top = yOrigin;
	clearRect.right = xOrigin + drawWidth - 1;
	clearRect.bottom = yOrigin + drawHeight - 1;
	FillRect(hdc, &clearRect, GetStockObject(WHITE_BRUSH));
	yOrigin += deltaY;
	x = xOrigin + deltaX;
	y = yOrigin;
	dottedPen = CreatePen(PS_DASH, 1, gray);
	SelectObject(hdc, dottedPen);
	for (i = 0; i < 25; i++) {
		MoveTo(hdc, x, y);
		LineTo(hdc, xOrigin + drawWidth - 1 - deltaX, y);
		y += deltaY;
	}
	DeleteObject(dottedPen);
	SelectObject(hdc, blackPen);
	y = yOrigin + 7 * deltaY;
	MoveTo(hdc, x, y);
	LineTo(hdc, x, y + 4 * deltaY);
	MoveTo(hdc, xOrigin + drawWidth - 1 - deltaX, y);
	LineTo(hdc, xOrigin + drawWidth - 1 - deltaX, y + 4 * deltaY);
	for (i = 0; i < 5; i++) {
		MoveTo(hdc, x, y + i * deltaY);
		LineTo(hdc, xOrigin + drawWidth - 1 - deltaX, y + i * deltaY);
	}
	y = yOrigin + 13 * deltaY;
	MoveTo(hdc, x, y);
	LineTo(hdc, x, y + 4 * deltaY);
	MoveTo(hdc, xOrigin + drawWidth - 1 - deltaX, y);
	LineTo(hdc, xOrigin + drawWidth - 1 - deltaX, y + 4 * deltaY);
	for (i = 0; i < 5; i++) {
		MoveTo(hdc, x, y + i * deltaY);
		LineTo(hdc, xOrigin + drawWidth - 1 - deltaX, y + i * deltaY);
	}
	noteCount = 0;
	for (i = pagePtr[*page]; i < eventCount; i++) {
		if (event[i].smFlag) {
			DWORD dwParam1 = event[i].shortMessage, dWord;
			DWORD d1 = (dwParam1 & 0xFF);
			DWORD d2 = (d1 & 0xF0);
			DWORD d3 = (d1 & 0x0F);
			DWORD dNote = (dwParam1 & 0xFF00) >> 8;
			DWORD dVelo = (dwParam1 & 0x00FF0000) >> 16;
			int tick0 = event[i].tick;

			if (d2 == NOTEON && dVelo > 0) {
				dWord = noteArray[noteCount].note = dNote;
				noteArray[noteCount].duration = 1.0;
				noteArray[noteCount].channel = d3;
				for (j = i + 1; j < eventCount; j++) {
					dwParam1 = event[j].shortMessage;
					d1 = (dwParam1 & 0xFF);
					d2 = (d1 & 0xF0);
					d3 = (d1 & 0x0F);
					dNote = (dwParam1 & 0xFF00) >> 8;
					dVelo = (dwParam1 & 0x00FF0000) >> 16;
				
					if ((dWord == dNote && d2 == NOTEOFF && d3 == noteArray[noteCount].channel) ||
						(dWord == dNote && dVelo == 0 && d3 == noteArray[noteCount].channel)) {
						int tick1 = event[j].tick;
						int elapsed = calculateElapsedTime(tick1 - tick0);
						
						noteArray[noteCount].duration = (elapsed * 1000.0) / rTempoInMPQ;
						if ((int) (noteArray[noteCount].duration + 0.5) > 4) {
							int count = (int) (0.5 + noteArray[noteCount].duration / 4.0), k;
							
							noteCount++;
							if (noteCount == 11)
								break;
							for (k = 0; k < count; k++) {
								noteArray[noteCount].note = dNote;
								noteArray[noteCount].duration = 4.0;
								noteArray[noteCount++].channel = d3;
								if (noteCount == 11)
									break;
							}
							if (noteCount == 11)
								break;
						}
						else {
							noteCount++;
							if (noteCount == 11)
								break;
						}
					}
				}
				if (noteCount == 11)
					break;
			}
		}
		else if (event[i].metaMessage == 81)
				rTempoInMPQ = event[i].shortMessage;
		else if (event[i].metaMessage == 88) {
			numer = (event[i].shortMessage & 0xFF000000) >> 24;
			denom = (event[i].shortMessage & 0x00FF0000) >> 16;
		}
	}
	wsprintf(message, "Numer: %02d", numer);
	TextOut(hdc, 32, 128, message, strlen(message));
	wsprintf(message, "Denom: %02d", denom);
	TextOut(hdc, 32, 160, message, strlen(message));
	wsprintf(message, "MIDI Format: %d", MIDIformat);
	TextOut(hdc, 32, 192, message, strlen(message));
	if (i < eventCount) {
		pagePtr[*page + 1] = i + 1;
		if (forward)
			(*page)++;
	}
	else {
		denom = numer = 0;
		*page = 0;
	}
	x = xOrigin + 3 * deltaX;
	for (i = 0; i < noteCount; i++) {
		BOOL sharp = FALSE;
		DWORD octave = (noteArray[i].note - 24) / 12, position;
		DWORD number = (noteArray[i].note - 24) % 12;

		if (number < 0)
			number += 12;
		if (number == 1 || number == 3 || number == 6 || number == 8 || number == 10) {
			sharp = TRUE;
			switch (number) {
				case 1:
					number = 0;
					break;
				case 3:
					number = 1;
					break;
				case 6:
					number = 3;
					break;
				case 8:
					number = 4;
					break;
				case 10:
					number = 5;
					break;
			}
		}
		else {
			sharp = FALSE;
			switch (number) {
				case 0:
					number = 0;
					break;
				case 2:
					number = 1;
					break;
				case 4:
					number = 2;
					break;
				case 5:
					number = 3;
					break;
				case 7:
					number = 4;
					break;
				case 9:
					number = 5;
					break;
				case 11:
					number = 6;
					break;
			}
		}
		position = 7 * octave + number;
		y = yOrigin + 24 * deltaY - (position + 3) * deltaY / 2;
		SelectObject(hdc, hPen[noteArray[i].channel]);
		SelectObject(hdc, hBrush[noteArray[i].channel]);
		if ((int) (noteArray[i].duration + 0.5) >= 4)
			Ellipse(hdc, x, y - deltaY / 2, x + deltaX, y + deltaY / 2);
		else if ((int) (noteArray[i].duration + 0.5) >= 2) {
			HRGN hRgn = CreateEllipticRgn(x, y - deltaY / 2, x + deltaX, y + deltaY / 2);
			
			FillRgn(hdc, hRgn, hBrush[noteArray[i].channel]);
			DeleteObject(hRgn);
		}
		else if ((int) (noteArray[i].duration + 0.2) >= 1) {
			HRGN hRgn = CreateEllipticRgn(x, y - deltaY / 2, x + deltaX, y + deltaY / 2);

			FillRgn(hdc, hRgn, hBrush[noteArray[i].channel]);
			MoveTo(hdc, x + deltaX, y - deltaY / 2);
			LineTo(hdc, x + deltaX, y - 3 * deltaY / 2);
			DeleteObject(hRgn);
		}
		else if (noteArray[i].duration >= 0.5 && noteArray[i].duration < 1.0) {
			HRGN hRgn = CreateEllipticRgn(x, y - deltaY / 2, x + deltaX, y + deltaY / 2);

			FillRgn(hdc, hRgn, hBrush[noteArray[i].channel]);
			MoveTo(hdc, x + deltaX, y - deltaY / 2);
			LineTo(hdc, x + deltaX, y - 3 * deltaY / 2);
			LineTo(hdc, x + deltaX + deltaX / 4, y - 3 * deltaY / 2);
			DeleteObject(hRgn);
		}
		else if (noteArray[i].duration >= 0.25 && noteArray[i].duration < 0.5) {
			HRGN hRgn = CreateEllipticRgn(x, y - deltaY / 2, x + deltaX, y + deltaY / 2);

			FillRgn(hdc, hRgn, hBrush[noteArray[i].channel]);
			MoveTo(hdc, x + deltaX, y - deltaY / 2);
			LineTo(hdc, x + deltaX, y - 3 * deltaY / 2);
			LineTo(hdc, x + deltaX + deltaX / 4, y - 3 * deltaY / 2);
			MoveTo(hdc, x + deltaX, y - 3 * deltaY / 2 - deltaY / 4);
			LineTo(hdc, x + deltaX + deltaX / 4, y - 3 * deltaY / 2 - deltaY / 4);
			DeleteObject(hRgn);
		}
		else if (noteArray[i].duration >= 0.125 && noteArray[i].duration < 0.25) {
			HRGN hRgn = CreateEllipticRgn(x, y - deltaY / 2, x + deltaX, y + deltaY / 2);

			FillRgn(hdc, hRgn, hBrush[noteArray[i].channel]);
			MoveTo(hdc, x + deltaX, y - deltaY / 2);
			LineTo(hdc, x + deltaX, y - 3 * deltaY / 2);
			LineTo(hdc, x + deltaX + deltaX / 4, y - 3 * deltaY / 2);
			MoveTo(hdc, x + deltaX, y - 3 * deltaY / 2 - deltaY / 4);
			LineTo(hdc, x + deltaX + deltaX / 4, y - 3 * deltaY / 2 - deltaY / 4);
			MoveTo(hdc, x + deltaX, y - 3 * deltaY / 2 - 2 * deltaY / 4);
			LineTo(hdc, x + deltaX + deltaX / 4, y - 3 * deltaY / 2 - 2 * deltaY / 4);
			DeleteObject(hRgn);
		}
		else {
			HRGN hRgn = CreateEllipticRgn(x, y - deltaY / 2, x + deltaX, y + deltaY / 2);

			FillRgn(hdc, hRgn, hBrush[noteArray[i].channel]);
			MoveTo(hdc, x + deltaX, y - deltaY / 2);
			LineTo(hdc, x + deltaX, y - 3 * deltaY / 2);
			LineTo(hdc, x + deltaX + deltaX / 4, y - 3 * deltaY / 2);
			MoveTo(hdc, x + deltaX, y - 3 * deltaY / 2 - deltaY / 4);
			LineTo(hdc, x + deltaX + deltaX / 4, y - 3 * deltaY / 2 - deltaY / 4);
			MoveTo(hdc, x + deltaX, y - 3 * deltaY / 2 - 2 * deltaY / 4);
			LineTo(hdc, x + deltaX + deltaX / 4, y - 3 * deltaY / 2 - 2 * deltaY / 4);
			MoveTo(hdc, x + deltaX, y - 3 * deltaY / 2 - 3 * deltaY / 4);
			LineTo(hdc, x + deltaX + deltaX / 4, y - 3 * deltaY / 2 - 3 * deltaY / 4);
			DeleteObject(hRgn);
		}
		if (sharp) {
			SetBkColor(hdc, RGB(255, 255, 255));
			SetTextColor(hdc, color[noteArray[i].channel]);
			TextOut(hdc, x - 3 * deltaX / 4, y - 3 * deltaY / 4, "#", 1);
		}
		x += 2 * deltaX;
	}
	ReleaseDC(hDlg, hdc);
}

BOOL CALLBACK SheetDlgProc(HWND hDlg, UINT iMsg, WPARAM wParam, LPARAM lParam) {
	int i, lastTick = 0, t = 0;
	static int page = 0;

	switch (iMsg) {
		case WM_INITDIALOG:
			rTempoInMPQ = 500000;
			if (MIDIformat == 0) {
				for (i = 0; i < eventCount; i++) {
					t = event[i].tick + lastTick;
					lastTick = event[i].tick = t;
				}
			}
			if (pagePtr == NULL) {
				pagePtr = malloc(eventCount * sizeof(int));
				if (pagePtr == NULL) {
					MessageBox(hDlg, "out of memory!", "Error Message", MB_OK | MB_ICONSTOP);
					exit(1);
				}
				pagePtr[0] = 0;
				page = 0;
			}
			return TRUE;
		case WM_COMMAND:
			switch (LOWORD(wParam)) {
				case IDOK:
				case IDCANCEL:
					EndDialog(hDlg, 0);
					free(pagePtr);
					pagePtr = NULL;
					return TRUE;
				case IDC_BUTTON1:
					DrawNotes(hDlg, FALSE, &page);
					return TRUE;
				case IDC_BUTTON2:
					DrawNotes(hDlg, TRUE, &page);
					return TRUE;
			}
	}
	return FALSE;
}

void InitializeOpenFilename(OPENFILENAME *openFilename) {
	static char szFilter[] = "All Files (*.*)\0*.mid\0\0";

	memset(openFilename, 0, sizeof(*openFilename));
	openFilename->lStructSize = sizeof(*openFilename);
	openFilename->lpstrFilter = szFilter;
	openFilename->nMaxFile = _MAX_PATH;
	openFilename->nMaxFileTitle = _MAX_FNAME + _MAX_EXT;
}

BOOL FindFileHandle(char *filename, int flags) {
	handle = open(filename, flags, S_IREAD);
	if (handle == - 1) {
		MessageBox(hWnd, "can't open file", "Warning Message",
			MB_ICONEXCLAMATION | MB_OK);
		return FALSE;
	}
	return TRUE;
}

LRESULT CALLBACK WndProc (HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam) {
	char none[32];
	int j, x, y;
	struct {
		long style;
		char *text;
	} button[] = {BS_PUSHBUTTON, "Connect", BS_PUSHBUTTON, "Open", BS_PUSHBUTTON, "Output",
		BS_PUSHBUTTON, "Pause", BS_PUSHBUTTON, "Sheet"};
	DWORD dWord1 = 0, dWord2 = 0;
	HDC hdc;
	PAINTSTRUCT ps;
	MIDIOUTCAPS midiOutCaps[16];
	RECT rect;
	UINT count = 0, i, nDevices, uMessage = 0, device[16];
	WSADATA wsaData;
	OPENFILENAME openFilename;
	static char filename[_MAX_FNAME + 1] = {'\0'};
	static char fileTitle[_MAX_FNAME + _MAX_EXT + 1] = {'\0'};
	static int cxClient, cyClient;
	static BOOL mouseOn = FALSE, rf;
	static RECT channelRect[16];

	switch (iMsg) {
		case WM_COMMAND:
			if (LOWORD(wParam) == 0) {
				if (connected == FALSE) {
					DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG1), hwnd, HostPortDlgProc);
					SetWindowText((HWND) lParam, "Close");
				}
				else {
					connected = FALSE;
					closesocket(sockfd);
					SetWindowText((HWND) lParam, "Connect");
				}
			}
			else if (LOWORD(wParam) == 1) {
				BOOL openFile;
				
				if (!started) {
					strcpy(none, "none");
					for (j = 4; j < 28; j++)
						none[j] = ' ';
					none[28] = '\0';
					for (j = 0; j < 16; j++)
						currentInstrumentLength[j] = wsprintf(currentInstrument[j], 
							"%02d %s", j, none);
					InitializeOpenFilename(&openFilename);
					openFilename.lpstrFile = filename;
					openFilename.lpstrFileTitle = fileTitle;
					openFilename.Flags = OFN_READONLY;
					if (GetOpenFileName(&openFilename)) {
						openFile = FindFileHandle(filename, O_BINARY | O_RDONLY);
						if (openFile) {
							EnterCriticalSection(&criticalSection);
							if (eventCount > 0) {
								eventCount = 0;
								free(event);
							}
							copyright[0] = '\0';
							started = TRUE;
							paused = FALSE;
							bufferCount = 0;
							ShowWindow(hwndButton[3], TRUE);
							ShowWindow(hwndButton[4], FALSE);
							SetWindowText(hwndButton[1], "Stop");
							LeaveCriticalSection(&criticalSection);
							_beginthread(Thread, 0, NULL);
						}
					}
				}
				else {
					EnterCriticalSection(&criticalSection);
					started = FALSE;
					bufferCount = 0;
					for (j = 0; j < 16; j++)
						midiOutShortMsg(hMidiOut, (123 << 8) + 176 + j);
					LeaveCriticalSection(&criticalSection);
					ShowWindow(hwndButton[3], FALSE);
					SetWindowText(hwndButton[1], "Open");
				}
				rect.left   = 0;
				rect.top    = 0;
				rect.right  = cxClient - 1;
				rect.bottom = cyClient - 1;
				InvalidateRect(hWnd, &rect, TRUE);
			}
			else if (LOWORD(wParam) == 2)
				DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG4), hwnd, OutputDlgProc);
			else if (LOWORD(wParam) == 3) {
				if (!paused) {
					EnterCriticalSection(&criticalSection);
					paused = TRUE;
					LeaveCriticalSection(&criticalSection);
					SetWindowText(hwndButton[3], "Restart");
				}
				else {
					EnterCriticalSection(&criticalSection);
					paused = FALSE;
					LeaveCriticalSection(&criticalSection);
					SetWindowText(hwndButton[3], "Pause");
				}
			}
			else if (LOWORD(wParam) == 4)
				DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG2), hwnd, SheetDlgProc);
			return 0;
		case WM_CREATE:
			if (WSAStartup(MAKEWORD(2, 0), &wsaData) != 0) {
				MessageBox(hwnd, "can't start up Windows sockets version 2.0\n", 
					"Error Message", MB_ICONSTOP | MB_OK);
				exit(1);
			}
			color[0] = RGB(255, 0, 0);
			color[1] = RGB(0, 255, 0);
			color[2] = RGB(0, 0, 255);
			color[3] = RGB(138, 43, 226);
			color[4] = RGB(100, 149, 237);
			color[5] = RGB(0, 206, 209);
			color[6] = RGB(127, 255, 212);
			color[7] = RGB(188, 143, 143);
			color[8] = RGB(244, 164, 96);
			color[9] = RGB(255, 255, 0);
			color[10] = RGB(255, 0, 255);
			color[11] = RGB(0, 255, 255);
			color[12] = RGB(139, 58, 98);
			color[13] = RGB(50, 205, 50);
			color[14] = RGB(255, 140, 0);
			color[15] = RGB(255, 20, 147);
			hBrush[0] = CreateSolidBrush(RGB(255, 0, 0));
			hBrush[1] = CreateSolidBrush(RGB(0, 255, 0));
			hBrush[2] = CreateSolidBrush(RGB(0, 0, 255));
			hBrush[3] = CreateSolidBrush(RGB(138, 43, 226));
			hBrush[4] = CreateSolidBrush(RGB(100, 149, 237));
			hBrush[5] = CreateSolidBrush(RGB(0, 206, 209));
			hBrush[6] = CreateSolidBrush(RGB(127, 255, 212));
			hBrush[7] = CreateSolidBrush(RGB(188, 143, 143));
			hBrush[8] = CreateSolidBrush(RGB(244, 164, 96));
			hBrush[9] = CreateSolidBrush(RGB(255, 255, 0));
			hBrush[10] = CreateSolidBrush(RGB(255, 0, 255));
			hBrush[11] = CreateSolidBrush(RGB(0, 255, 255));
			hBrush[12] = CreateSolidBrush(RGB(139, 58, 98));
			hBrush[13] = CreateSolidBrush(RGB(50, 205, 50));
			hBrush[14] = CreateSolidBrush(RGB(255, 140, 0));
			hBrush[15] = CreateSolidBrush(RGB(255, 20, 147));
			hPen[0] = CreatePen(PS_SOLID, 1, RGB(255, 0, 0));
			hPen[1] = CreatePen(PS_SOLID, 1, RGB(0, 255, 0));
			hPen[2] = CreatePen(PS_SOLID, 1, RGB(0, 0, 255));
			hPen[3] = CreatePen(PS_SOLID, 1, RGB(138, 43, 226));
			hPen[4] = CreatePen(PS_SOLID, 1, RGB(100, 149, 237));
			hPen[5] = CreatePen(PS_SOLID, 1, RGB(0, 206, 209));
			hPen[6] = CreatePen(PS_SOLID, 1, RGB(127, 255, 212));
			hPen[7] = CreatePen(PS_SOLID, 1, RGB(188, 143, 143));
			hPen[8] = CreatePen(PS_SOLID, 1, RGB(244, 164, 96));
			hPen[9] = CreatePen(PS_SOLID, 1, RGB(255, 255, 0));
			hPen[10] = CreatePen(PS_SOLID, 1, RGB(255, 0, 255));
			hPen[11] = CreatePen(PS_SOLID, 1, RGB(0, 255, 255));
			hPen[12] = CreatePen(PS_SOLID, 1, RGB(139, 58, 98));
			hPen[13] = CreatePen(PS_SOLID, 1, RGB(50, 205, 50));
			hPen[14] = CreatePen(PS_SOLID, 1, RGB(255, 140, 0));
			hPen[15] = CreatePen(PS_SOLID, 1, RGB(255, 20, 147));
			InitializeCriticalSection(&criticalSection);
			strcpy(none, "none");
			for (j = 4; j < 28; j++)
				none[j] = ' ';
			none[28] = '\0';
			for (j = 0; j < 16; j++)
				currentInstrumentLength[j] = wsprintf(currentInstrument[j], "%02d %s", j, none);
			{
				struct hostent *he;
				char host[128];

				gethostname(host, 128);
				he = gethostbyname(host);
				MessageBox(hwnd, he->h_name, "Information Message", MB_ICONEXCLAMATION | MB_OK);
				{
					char str[128], **pptr;
					int a[4];
					
					for (j = 0; j < he->h_length; j++) {
						a[j] = (int) he->h_addr_list[0][j];
						if (a[j] < 0)
							a[j] += 256;
					}
					wsprintf(str, "%d.%d.%d.%d", a[0], a[1], a[2], a[3]);
					MessageBox(hwnd, str, "Information Message", MB_ICONEXCLAMATION | MB_OK);
					he = gethostbyname(str);
					if (he != NULL) {
						MessageBox(hwnd, he->h_name, "Information Message", MB_ICONEXCLAMATION | MB_OK);
						for (pptr = he->h_aliases; *pptr != NULL; pptr++)
							MessageBox(hwnd, *pptr, "Information Message", MB_ICONEXCLAMATION | MB_OK);
					}
				}
			}
			/* create buttons */
			{
				int cxChar, cyChar, height, x, y;
				HDC hDC = GetDC(hwnd);
				TEXTMETRIC textMetric;

				GetTextMetrics(hDC, &textMetric);
				cxChar = textMetric.tmAveCharWidth;
				cyChar = textMetric.tmHeight + textMetric.tmExternalLeading;
				x = 4 * cxChar;
				y = 2 * cyChar;
				height = 7 * cyChar / 4;
				for (i = 0; i < NUMBERBUTTONS; i++) {
					int width = 10 * cxChar;
					
					hwndButton[i] = CreateWindow("button", button[i].text,
						WS_CHILD | WS_VISIBLE | button[i].style, x, y, width, height,
						hwnd, (HMENU) i, ((LPCREATESTRUCT) lParam)->hInstance, NULL);
					x += width + 4 * cxChar;
				}
				ShowWindow(hwndButton[3], FALSE);
				ShowWindow(hwndButton[4], FALSE);
			}
			nDevices = midiOutGetNumDevs();
			for (i = 0; i < nDevices; i++) {
				WORD wTechnology;

				if (midiOutGetDevCaps(i, &midiOutCaps[i], sizeof(midiOutCaps[i])) !=
					MMSYSERR_NOERROR) {
					MessageBox (hwnd, "can't get device capabilities", "Error Message",
								MB_ICONSTOP | MB_OK);
					exit(1);
				}
				wTechnology = midiOutCaps[i].wTechnology;
				if ((wTechnology & MOD_SYNTH) | (wTechnology & MOD_SQSYNTH) ||
					(wTechnology & MOD_FMSYNTH) && count < 16)
					device[count++] = i;
			}
			if (count == 0) {
				MessageBox (hwnd, "can't find a synthesizer", "Error Message",
							MB_ICONSTOP | MB_OK);
				exit(1);
			}
			for (i = 0; i < count; i++)
				if (midiOutOpen(&hMidiOut, device[i], CALLBACK_NULL, CALLBACK_NULL, CALLBACK_NULL) == 
							MMSYSERR_NOERROR)
					break;
			MessageBox(hwnd, midiOutCaps[device[i]].szPname, "Information Message", MB_OK);
			if (i == count) {
				MessageBox (hwnd, "can't get open synthesizer", "Error Message",
							MB_ICONSTOP | MB_OK);
				exit(1);
			}
			return 0;
		case WM_SIZE:
			EnterCriticalSection(&criticalSection);
			cxClient = LOWORD(lParam);
			cyClient = HIWORD(lParam);
			whiteKeyWidth = cxClient / 44;
			whiteKeyHeight = cyClient / 6;
			for (i = 0; i < 42; i++) {
				whiteKeyX0[i] = whiteKeyWidth * i + whiteKeyWidth;
				whiteKeyX1[i] = whiteKeyX0[i] + whiteKeyWidth;
				whiteKeyY0[i] = whiteKeyHeight;
				whiteKeyY1[i] = whiteKeyY0[i] + whiteKeyHeight;
			}
			for (i = 0; i < 6; i++) {
				blackKeyX0[5 * i + 0] = whiteKeyX0[7 * i + 0] + 3 * whiteKeyWidth / 4;
				blackKeyX1[5 * i + 0] = blackKeyX0[5 * i + 0] + whiteKeyWidth / 2;
				blackKeyY0[5 * i + 0] = whiteKeyHeight;
				blackKeyY1[5 * i + 0] = blackKeyY0[5 * i + 0] + 2 * whiteKeyHeight / 3;
				blackKeyX0[5 * i + 1] = whiteKeyX0[7 * i + 1] + 3 * whiteKeyWidth / 4;
				blackKeyX1[5 * i + 1] = blackKeyX0[5 * i + 1] + whiteKeyWidth / 2;
				blackKeyY0[5 * i + 1] = whiteKeyHeight;
				blackKeyY1[5 * i + 1] = blackKeyY0[5 * i + 1] + 2 * whiteKeyHeight / 3;
				blackKeyX0[5 * i + 2] = whiteKeyX0[7 * i + 3] + 3 * whiteKeyWidth / 4;
				blackKeyX1[5 * i + 2] = blackKeyX0[5 * i + 2] + whiteKeyWidth / 2;
				blackKeyY0[5 * i + 2] = whiteKeyHeight;
				blackKeyY1[5 * i + 2] = blackKeyY0[5 * i + 2] + 2 * whiteKeyHeight / 3;
				blackKeyX0[5 * i + 3] = whiteKeyX0[7 * i + 4] + 3 * whiteKeyWidth / 4;
				blackKeyX1[5 * i + 3] = blackKeyX0[5 * i + 3] + whiteKeyWidth / 2;
				blackKeyY0[5 * i + 3] = whiteKeyHeight;
				blackKeyY1[5 * i + 3] = blackKeyY0[5 * i + 3] + 2 * whiteKeyHeight / 3;
				blackKeyX0[5 * i + 4] = whiteKeyX0[7 * i + 5] + 3 * whiteKeyWidth / 4;
				blackKeyX1[5 * i + 4] = blackKeyX0[5 * i + 4] + whiteKeyWidth / 2;
				blackKeyY0[5 * i + 4] = whiteKeyHeight;
				blackKeyY1[5 * i + 4] = blackKeyY0[5 * i + 4] + 2 * whiteKeyHeight / 3;
			}
			for (i = 0; i < 42; i++) {
				for (j = 0; j < bufferCount; j++) {
					if (buffer[j].white && buffer[j].index == (int) i) {
						buffer[j].currentKeyX0 = whiteKeyX0[i];
						buffer[j].currentKeyY0 = whiteKeyY0[i];
						buffer[j].currentKeyX1 = whiteKeyX1[i];
						buffer[j].currentKeyY1 = whiteKeyY1[i];
						break;
					}
				}
			}
			for (i = 0; i < 30; i++) {
				for (j = 0; j < bufferCount; j++) {
					if (!buffer[j].white && buffer[j].index == (int) i) {
						buffer[j].currentKeyX0 = blackKeyX0[i];
						buffer[j].currentKeyY0 = blackKeyY0[i];
						buffer[j].currentKeyX1 = blackKeyX1[i];
						buffer[j].currentKeyY1 = blackKeyY1[i];
					}
				}
			}
			x = 16;
			y = 2 * whiteKeyHeight + 16;
			for (j = 0; j < 16; j++) {
				channelRect[j].left = x;
				channelRect[j].top = y;
				channelRect[j].right = x + 16;
				channelRect[j].bottom = y + 8;
				textX[j] = x + 32;
				textY[j] = y;
				y += 16;
			}
			rect.left   = 0;
			rect.top    = 0;
			rect.right  = cxClient - 1;
			rect.bottom = cyClient - 1;
			LeaveCriticalSection(&criticalSection);
			InvalidateRect(hWnd, &rect, TRUE);
			return 0;
		case WM_PAINT:
			EnterCriticalSection(&criticalSection);
			hdc = BeginPaint(hWnd, &ps);
			PaintWindow(hdc);
			for (j = 0; j < 16; j++) {
				FillRect(hdc, &channelRect[j], hBrush[j]);
				TextOut(hdc, textX[j], textY[j], currentInstrument[j],
					currentInstrumentLength[j]);
			}
			EndPaint(hWnd, &ps);
			LeaveCriticalSection(&criticalSection);
			return 0;
		case WM_DESTROY:
			if (hMidiOut != NULL)
				midiOutClose(hMidiOut);
			if (connected)
				closesocket(sockfd);
			if (eventCount != 0)
				free(event);
			for (j = 0; j < 16; j++) {
				DeleteObject(hBrush[j]);
				DeleteObject(hPen[j]);
			}
			PostQuitMessage(0);
			return 0;
	}
	return DefWindowProc(hwnd, iMsg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
				   PSTR szCmdLine, int iCmdShow) {
	static char szAppName[] = "MIDI Keyboard to Synthesizer";
	static char title[] = "Windows Sequencer by James Pate Williams, Jr. (c) 2003";
	MSG msg;
	WNDCLASSEX  wndclass;

	InitInstrument();
	wndclass.cbSize        = sizeof (wndclass);
	wndclass.style         = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc   = WndProc;
	wndclass.cbClsExtra    = 0;
	wndclass.cbWndExtra    = 0;
	wndclass.hInstance     = hInstance;
	wndclass.hIcon         = NULL;
	wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW);
	wndclass.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);
	wndclass.lpszMenuName  = NULL;
	wndclass.lpszClassName = szAppName;
	wndclass.hIconSm       = NULL;
	RegisterClassEx (&wndclass);
	hWnd = CreateWindow(szAppName, title, WS_OVERLAPPEDWINDOW,
						CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
						CW_USEDEFAULT, NULL, NULL, hInstance, NULL);
	hInst = hInstance;
	ShowWindow(hWnd, iCmdShow);
	UpdateWindow(hWnd) ;
	while (GetMessage(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}